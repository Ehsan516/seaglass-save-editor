# Seaglass Save Editor

> A modern, skeuomorphic save editor for **Pokémon Emerald Seaglass** — built because PKHeX doesn't support the hack.

![Seaglass Save Editor](docs/screenshot.png)

![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![GUI](https://img.shields.io/badge/GUI-PySide6-41cd52)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)
![License](https://img.shields.io/badge/license-MIT-green)

Pokémon Emerald Seaglass is built on **pokeemerald-expansion**, which renumbers species, moves and items and reshapes the save layout — so PKHeX and other vanilla-Emerald tools read it as garbage. This editor was reverse-engineered directly from the Seaglass ROM and a real save, so it speaks Seaglass's dialect natively.

---

## Features

- **Edit the full standard set:** species, nickname, nature, **gender**, **shininess**, level, friendship, held item, all four moves (+ PP), and all six IVs and EVs.
- **Name-based pickers** — searchable dropdowns for **~935 moves** and **~1,000 items** pulled straight from the ROM (type `rock`, `leftovers`, `mint`… to filter). No index hunting.
- **Safe by construction:**
  - Party stats are **recomputed** on save (correct Gen-3 formula), so the game never silently reverts an edited level.
  - Nature, **gender**, and **shininess** are changed by rerolling the personality value **while preserving the other two and the ability slot** — toggle one, the rest stay put. (Gender respects each species' ratio; genderless/single-gender species are locked.)
  - Every write fixes both the Pokémon checksum and the section checksum; edits the active slot only.
- **Reads party *and* PC boxes.**
- **Skeuomorphic "handheld" UI** — frosted emerald plates, an inset LCD list, tactile buttons.
- **Never touches your original** — "Save As…" defaults to a new `*_edited.sav`.

---

## Requirements

- Python 3.9+
- [PySide6](https://pypi.org/project/PySide6/)
- A clean **Pokémon Emerald Seaglass** ROM (for names, base stats, gender data) and your `.sav`.

```bash
pip install -r requirements.txt
```

## Installation

```bash
git clone https://github.com/<you>/seaglass-save-editor.git
cd seaglass-save-editor
pip install -r requirements.txt
python seaglass_editor.py
```

> **Windows note:** use `python` (or `py -3.12`), **not** `python3` — Windows redirects `python3` to a Microsoft Store stub. If you see *"PySide6 not installed"* even after installing it, your `pip` and your launcher are pointing at different Pythons; run `py -m pip install PySide6` to line them up.

---

## Building a standalone `.exe` (Windows)

End users shouldn't need Python or an IDE — bundle everything into one executable with [PyInstaller](https://pyinstaller.org/):

```bat
python -m pip install pyinstaller
python -m PyInstaller --onefile --windowed --name SeaglassSaveEditor --icon app.ico seaglass_editor.py
```

The result is **`dist/SeaglassSaveEditor.exe`** — a single self-contained file. `seaglass_save.py` and `theme.py` are pulled in automatically (keep all three `.py` files together when building). Or just double-click **`build.bat`**.

Notes: the one-file exe is large (~80–150 MB) and unsigned, so Windows SmartScreen may warn on first run ("More info → Run anyway"). It still needs the user to supply their own ROM and save — neither is bundled. Build on the OS you're targeting (a Windows build runs on Windows only).

## Usage

1. **Open Save…** → pick your `.sav`.
2. **Open ROM…** → pick the Seaglass `.gba`. (Required for names, base stats, and safe nature/level edits.)
3. Select a Pokémon from the party or PC boxes on the left.
4. Edit fields on the right → **Apply to Pokémon**.
5. **Save As…** → writes a new `.sav` (your original is left untouched).

### Getting an edited save back onto a 3DS (GBA Virtual Console)

If you play Seaglass as a GBA VC inject on a homebrewed 3DS/2DS, the save lives **inside the title's encrypted 3DS save data**, not as a loose file — so you go through GodMode9:

1. **Dump** the save in GodMode9 → you get `<titleID>_gbavc.sav` in `gm9/out/`.
2. Edit it with this tool → `..._edited.sav`.
3. **Inject** the edited file back into the **same title** in GodMode9. It recomputes the CMAC the VC wrapper requires — a raw byte swap won't boot.
4. **Keep the original dump as a backup**, then boot and check your party.

> If you instead run the ROM through **open_agb_firm**, the save is a plain `.sav` in `/3ds/open_agb_firm/saves/` — just swap the file, no CMAC step.

---

## How it works

Reverse-engineered facts this tool relies on (useful if you're hacking Seaglass yourself):

| Area | Detail |
|------|--------|
| Save container | 128 KB Flash, 2 slots × 14 sections × 4 KB; footer @`0xFF4` (`u16` id, `u16` checksum, `u32` sig `0x08012025`, `u32` counter). Active slot = highest counter. |
| Species indexing | **National Dex number** (expansion convention), not vanilla internal order. |
| Party | `SaveBlock1 + 0x234` count, `+0x238` six 100-byte Pokémon. |
| Pokémon crypto | key = `PV ^ OTID`; substructure order = `PV % 24`; checksum = sum of 24 LE `u16`. |
| Base stats | `SpeciesInfo` stride `0xD0`; name @`+0x2c`, stats @`+0x00` (HP/Atk/Def/Spe/SpA/SpD), gender ratio @`+0x12`. |
| Move names | `gMovesInfo` name pointers — field @`0x6d2a18`, stride `0x38`. |
| Item names | embedded @`0x67e77c`, stride `0x54`, indexed by item ID (expansion order: 1=Poké Ball, 2=Great, 3=Ultra, 4=Master, …). |
| Ability | stored in Misc bit 31 (not derived from PV) — so nature edits preserve it automatically. |

Growth rate (for level↔exp) is auto-detected per Pokémon from its current `(exp, level)` pair, so no extra ROM table is needed.

## Project layout

```
seaglass_save.py     # read/write engine (no GUI; importable & scriptable)
seaglass_editor.py   # PySide6 GUI
theme.py             # skeuomorphic stylesheet (tweak the palette here)
app.ico              # application icon (faceted emerald)
build.bat            # one-click Windows build -> dist/SeaglassSaveEditor.exe
requirements.txt
docs/screenshot.png
```

The engine is usable on its own:

```python
from seaglass_save import SeaglassSave
s = SeaglassSave("your.sav", "seaglass.gba")
for m in s.party():
    print(s.species_name(m.species), m.level, [s.move_name(x) for x in m.moves])
```

---

## Limitations

- **Ability names** aren't shown yet (the ability *slot* 0/1 is shown and preserved).
- **PP isn't auto-set** when you change a move — adjust it manually if you care.
- **Species change across different growth-rate groups:** set the level *after* applying the species change once.
- Move/item name pickers require the ROM to be loaded.

## Disclaimer

For personal use with **your own** legally-obtained copy of the game. Always **back up your save** before editing. This project ships **no ROM and no game assets**. It is not affiliated with or endorsed by Nintendo, Game Freak, or the Seaglass author.

## Credits

- **Pokémon Emerald Seaglass** by **Nemo622** — [ko-fi.com/nemo622](https://ko-fi.com/nemo622)
- Built on **[pokeemerald-expansion](https://github.com/rh-hideout/pokeemerald-expansion)** by the RH Hideout community
- Save editor: you 🙂

## License

[MIT](LICENSE)
